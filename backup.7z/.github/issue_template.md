
<!--
  By opening this issue you confirm that you have searched for similar issues/PRs here already.
  Failing to do so will most likely result in closing of this issue without any explanation.
-->

#### Scoop Configuration
<!-- Can be found in  ~/.config/scoop/config.json -->

```json
//# Your configuration here
```
